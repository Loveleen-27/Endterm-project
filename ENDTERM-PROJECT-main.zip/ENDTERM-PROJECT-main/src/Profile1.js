import React from 'react'
// import './Profile1.module.css'
import background from './Images/girls_profile.png'
export default function Profile1() {
  return (
    <>
       {/* <div className="container"> */}

{/* <header>
    <div className="brandLogo">
        <span>Shubh Vivaah</span>
    </div>
</header> */}
<header className="page-header header container-fluid" style={{backgroundImage:`url(${background})`}}>
</header>


{/* <section className="userProfile card">
    <div className="profile">
        <figure><img src={require("./Images/b1.jpg")} alt="profile" width="250px" height="250px"/></figure>
    </div>
</section> 



<section className="work_skills card">

    
    <div className="work">
        <li className="sex">
            <h5 className="label">Gender:</h5>
            <span className="info">Female</span>
        </li>
        
        <li className="religion">
            <h5 className="label">Religion:</h5>
            <span className="info">HINDU</span>
        </li>

        <li className="height">
            <h5 className="label">Height:</h5>
            <span className="info">5'5"</span>
        </li>

        <li className="birthday">
            <h5 className="label">Birthday:</h5>
            <span className="info">Oct 22, 1996</span>
        </li>

        <li className="place">
            <h5 className="label">Place of birth:</h5>
            <span className="info">Delhi</span>
        </li>


    </div>

</section>



<section className="userDetails card">
    <div className="userName">
        <h5 className="name">Tanya Gupta</h5>
            <p>Delhi, India</p>
            <button type="button" className="btn btn-primary">Send Request</button>
    </div>

</section>


<section className="timeline_about card">
    <div className="tabs">
        <ul>
            <li className="about active">
                <i className="ri-user-3-fill ri"></i>
                <span>About</span>
            </li>
        </ul>
    </div>
    <div className="contact_Info">
        
            <li className="brief">
                <h5 className="label">Brief about me:</h5>
                <span className="info">"I am a 26 year old 5'5" tall, slim woman, based in Delhi. I have MBBS degree from AIMS and an MS from New York. I am currently practicing as a cardiologist in a well-reputed hospital of Delhi. I intend to pursue my career after marriage and looking for someone who will appreciate living with a progressive, independent woman. I love reading books and collecting the antiques."</span>
            </li>

            <li className="parents">
                <h5>Mother :</h5>Seema Gupta
                <h5>Father :</h5>Ramesh Gupta
            </li>

            <li className="education">
                <h5 className="label">Education :</h5>
                <span className="info">MBBS</span>
            </li>

        
    </div>
</section>
</div> */}
    </>
  )
}
