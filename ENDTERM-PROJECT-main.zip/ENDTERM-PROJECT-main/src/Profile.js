import React from 'react'
// import './Profile.module.css'
import background from './Images/boys_profile.png'
export default function Profile() {
  return (
    <>
       {/* <div className="container"> */}

{/* <header>
    <div className="brandLogo">
        <span>Shubh Vivaah</span>
    </div>
</header> */}
<header className="page-header header container-fluid"  style={{backgroundImage:`url(${background})`}}>
</header>


{/* <section className="userProfile card">
    <div className="profile">
        <figure><img src={require("./Images/b1.jpg")} alt="profile" width="250px" height="250px"/></figure>
    </div>
</section> 



<section className="work_skills card">

    
    <div className="work">
        <li className="sex">
            <h5 className="label">Gender:</h5>
            <span className="info">Male</span>
        </li>
        
        <li className="religion">
            <h5 className="label">Religion:</h5>
            <span className="info">HINDU</span>
        </li>

        <li className="height">
            <h5 className="label">Height:</h5>
            <span className="info">6'2</span>
        </li>

        <li className="birthday">
            <h5 className="label">Birthday:</h5>
            <span className="info">Dec 25, 1993</span>
        </li>

        <li className="place">
            <h5 className="label">Place of birth:</h5>
            <span className="info">Mumbai</span>
        </li>


    </div>

</section>



<section className="userDetails card">
    <div className="userName">
        <h5 className="name">Sachin Sharma</h5>
            <p>Mumbai, Maharashtra</p>
            <button type="button" className="btn btn-primary">Send Request</button>
    </div>

</section>


<section className="timeline_about card">
    <div className="tabs">
        <ul>
            <li className="about active">
                <i className="ri-user-3-fill ri"></i>
                <span>About</span>
            </li>
        </ul>
    </div>
    <div className="contact_Info">
        
            <li className="brief">
                <h5 className="label">Brief about me:</h5>
                <span className="info">I am a tall, handsome, 28-year-old man looking for a chance to find true love. I am a longtime practitioner of yoga and believe in leading a simple lifestyle. I don’t believe in entering a rat race to acquire material comforts and would rather pay attention to building closer relationships with family and friends. </span>
            </li>

            <li className="parents">
                <h5>Mother :</h5>Usha Sharma
                <h5>Father :</h5>Mahesh Sharma
            </li>

            <li className="education">
                <h5 className="label">Education :</h5>
                <span className="info">M.tech</span>
            </li>

        
    </div>
</section>
</div> */}
    </>
  )
}
